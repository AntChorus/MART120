function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  rect(170, 300, 60, 100);
  ellipse(200, 200, 200, 300)
  ellipse(160, 150, 40, 30);
  ellipse(240, 150, 40, 30);
  circle(160,150, 10);
  circle(240, 150, 10);
  point(160, 150);
  point(240, 150);
  rect(135, 125, 50, 5);
  rect(215, 125, 50, 5);
  triangle(187, 213, 200, 175, 213, 213);
  rect(150, 270, 100, 5);
  line(200, 50, 100, 200);
  line(200, 50, 300, 200);
  line(300, 200, 300, 400);
  line(100, 200, 100, 400);
  circle(200, 500, 250)
  textSize(20);
  text("Oscar Hunt", 285, 390);
  text("Self-Portrait", 10, 20);
 
}