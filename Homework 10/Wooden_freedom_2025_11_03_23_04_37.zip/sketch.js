var x = 170;
var movement = 2;
var x2 = 200;
var movement2 = -2;
var y = 120;
var y2 = 120;
var ne = 187;
var ni = 213;
var mo = 5;
var ts = 5;
var m = 1;
//A note here, ne, ni, and mo, are x y and movement for the triangle. I wanted a shorter variable that I could type quicker and I knew that I'd be the only one working with this code. I also want to note that the nose stretching is intentional, and is my diagonal movement for this assignment. 
function setup() {
  createCanvas(400, 400);
  movement = floor(random() * 10);
    movement = floor(random() * 2);
}

function draw() {
  background(220);
  rect(x, 300, 60, 100);
  ellipse(x2, 200, 200, 300);
  ellipse(160, 150, 40, 30);
  ellipse(240, 150, 40, 30);
  circle(160,150, 10);
  circle(240, 150, 10);
  point(160, 150);
  point(240, 150);
  rect(135, y, 50, 5);
  rect(215, y, 50, 5);
  triangle(ne, ni, 200, 175, 213, 213);
  rect(150, 270, 100, 5);
  line(200, 50, 100, 200);
  line(200, 50, 300, 200);
  line(300, 200, 300, 400);
  line(100, 200, 100, 400);
  circle(200, 500, 250)
  textSize(ts);
  text("Oscar Hunt", 285, 390);
  text("Self-Portrait", 10, 20);
   if (x >= 400 || x <= 0) {
    movement *= -1;
   }
     if (x2 >= 400 || x2 <= 0) {
    movement2 *= -1;
   }
 x = x+movement;
  x2 = x2+movement2;
  y=y+movement*5;
  y=y2+movement2*5;
  ne = ne+mo;
  ni = ni+mo;
     if (ne >= 400 || ne <= 0) {
    mo *= -1;
    ts = ts+5*m;
   }
       if (ts >= 29 || ts <= 6) {
    m = m*-1;
   }
  
}