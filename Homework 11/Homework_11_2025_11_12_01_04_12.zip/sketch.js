  var x = 200;
    var y = 200;
    var diameter = 25;
var e1x = 100;
var e1y = 100;
var e2x = 250;
var e2y = 300;
var speed = 5;
var obstacle = 0;
function setup() {
  createCanvas(400, 400);

}

function draw() {
  background(200);
  fill(0, 0, 200);
  circle(x,y,diameter);
  fill(e1x, e1y, speed);
  rect(e1x, e1y, 20, 50);
  fill(e2y, speed, e2x);
  circle(e2x, e2y, 42)
  if(obstacle > 0)
    circle(100, 300, 50);
  fill(0, 300, 0);
  rect(390, 200, 10, 100);
if(keyIsDown(68))
  {
      x+=speed;
  }
  if(keyIsDown(65))
  {
      x-=speed;
  }
    if(keyIsDown(83))
  {
      y+=speed;
  }
    if(keyIsDown(87))
  {
      y-=speed;
  }
     if (x > 400) {
    e1x = 0;
  }
   if (e1x > 400) {
    e1x = 0;
  }
   else if (e1x < 0) {
    e1x = 400;
  }
   if (e1y > 400) {
    e1y = 0;
  }
     else if (e1y < 0) {
    e1y = 400;
  }
  e1x=e1x+random(20);
  e1y=e1y+random(20);
   if (e2x > 400) {
    e2x = 0;
  }
   else if (e2x < 0) {
    e2x = 400;
  }
   if (e2y > 400) {
    e2y = 0;
  }
     else if (e2y < 0) {
    e2y = 400;
  }
  e2x=e2x+random(5);
  e2y=e2y+random(12);
if (x>400 && y>200 && y<300) {
  fill(0);
  textSize(70);
  text('YOU WIN', 50, 200);
}
}
function mouseClicked() {
  obstacle = obstacle+1;
}


