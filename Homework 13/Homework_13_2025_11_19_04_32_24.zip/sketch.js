     var X = [];
    var Y = [];
    var D = [];
var nmo = 0;
var enemySpeed = [];
 X[0] = 200;
 Y[0] = 200;
 D[0] = 25;
 X[1] = 300;
 Y[1] = 100;
 D[1] = 60;
 X[2] = 250;
 Y[2] = 300;
 D[2] = 23;
 X[3] = 123;
 Y[3] = 300;
 D[3] = 100;
 X[4] = 333;
 Y[4] = 123;
 D[4] = 12;
 X[5] = 240;
 Y[5] = 133;
 D[5] = 55;
var speed = 5;
var obstacle = 0;
function setup() {
  createCanvas(400, 400);

}

function draw() {
  background(200);
  CreatePlayer();
  MovePlayer();
  enemies();
  newObstacle();
  moveEnemy1();
  moveEnemy2();
  moveEnemy3();
  moveEnemy4();
  moveEnemy5();
  drawBorder();
  drawExit();
  youWin();
}

function CreatePlayer() {
fill(0, 0, 200);
circle(X[0],Y[0],D[0]);
}

function MovePlayer() {
  if(keyIsDown(68))
  {
      X[0]+=speed;
  }
  if(keyIsDown(65))
  {
      X[0]-=speed;
  }
    if(keyIsDown(83))
  {
      Y[0]+=speed;
  }
    if(keyIsDown(87))
  {
      Y[0]-=speed;
  }
}

function newObstacle() {
   if(mouseIsPressed===true)
nmo = 1;
  if (nmo > 0){
    fill (500, 0, 0);
circle(100, 100, 100);
    }
}

function enemies() {
        for(var i = 1; i < X.length; i++)
        {
            fill(Y[i], D[i], X[i]);      
            circle(X[i],Y[i],D[i]);
        }
  }
function moveEnemy1() {
     if (X[1] > 400) {
    X[1] = 0;
  }
   else if (X[1] < 0) {
    X[1] = 400;
  }
   if (Y[1] > 400) {
    Y[1] = 0;
  }
     else if (Y[1] < 0) {
    Y[1] = 400;
  }
  X[1]=X[1]+random(20);
  Y[1]=Y[1]+random(20);
}

function moveEnemy2() {
    if (X[2] > 400) {
    X[2] = 0;
  }
   else if (X[2] < 0) {
    X[2] = 400;
  }
   if (Y[2] > 400) {
    Y[2] = 0;
  }
     else if (Y[2] < 0) {
    Y[2] = 400;
  }
  X[2]=X[2]+random(5);
  Y[2]=Y[2]+random(12);
}function moveEnemy3() {
     if (X[3] > 400) {
    X[3] = 0;
  }
   else if (X[3] < 0) {
    X[3] = 400;
  }
   if (Y[3] > 400) {
    Y[3] = 0;
  }
     else if (Y[3] < 0) {
    Y[3] = 400;
  }
  X[3]=X[3]+random(23);
}
function moveEnemy4() {
     if (X[4] > 400) {
    X[4] = 0;
  }
   else if (X[4] < 0) {
    X[4] = 400;
  }
   if (Y[4] > 400) {
    Y[4] = 0;
  }
     else if (Y[4] < 0) {
    Y[4] = 400;
  }
  X[4]=X[4]+random(3);
  Y[4]=Y[4]+random(23);
}
function moveEnemy5() {
     if (X[5] > 400) {
    X[5] = 0;
  }
   else if (X[5] < 0) {
    X[5] = 400;
  }
   if (Y[5] > 400) {
    Y[5] = 0;
  }
     else if (Y[5] < 0) {
    Y[5] = 400;
  }
  X[5]=X[5]+random(34);
  Y[5]=Y[5]+random(0);
}

function drawBorder() {
  fill(0);
  rect(0, 0, 10, 400);
  rect(0, 390, 400, 10);
  rect(390, 0, 10, 400);
  rect(0, 0, 400, 10);
}

function drawExit () {
   fill(0, 300, 0);
  rect(385, 200, 15, 100);
}

function youWin() {
  if (X[0]>400 && Y[0]>200 && Y[0]<300) {
  fill(0);
  textSize(70);
  text('YOU WIN', 50, 200);
}
}